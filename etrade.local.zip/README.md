# Florar.md

Admin panel build using Laravel and Filament.

[Laravel documentation](https://laravel.com/docs/11.x)

[Filament documentation](https://filamentphp.com/docs/3.x/panels/installation)
