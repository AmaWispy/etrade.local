<?php 

return [
    'shop' => 'principala',
];