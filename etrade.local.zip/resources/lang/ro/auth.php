<?php

return [
    'failed' => 'Aceste acreditări nu se potrivesc cu înregistrările noastre.',
    'password' => 'Parola furnizată este incorectă.',
    'throttle' => 'Prea multe încercări de autentificare. Vă rugăm să încercați din nou în :seconds secunde.',

];
