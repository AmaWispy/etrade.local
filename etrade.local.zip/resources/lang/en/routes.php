<?php 

return [
    'shop' => 'shop',
];