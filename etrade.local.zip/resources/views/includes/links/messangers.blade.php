<ul class="inline-flex items-center gap-1 pl-2 !m-0">
    <li class="!m-1"><a href="viber://chat?number={{ $templateSettings['company-telephone'] }}"><img class="h-6" src="{{ asset('template/svg/viber.svg') }}" alt=""></a></li>
    <li class="!m-1"><a href="https://t.me/username"></a><img class="h-6" src="{{ asset('template/svg/telegram.svg') }}" alt=""></li>
    <li class="!m-1"><a href="https://wa.me:/chat?number={{ $templateSettings['company-telephone'] }}"><img class="h-6" src="{{ asset('template/svg/whatsapp.svg') }}" alt=""></a></li>
    <li class="!m-1"><a href="https://m.me:/username"></a><img class="h-6" src="{{ asset('template/svg/messenger-facebook.svg') }}" alt=""></li>
</ul>