<ul class="!inline-flex gap-3 h-full">
    <li class="!m-0"><img src="{{ asset('template/svg/mastercard.svg') }}" class="h-full" alt="MasterCard"></li>
    <li class="!m-0"><img src="{{ asset('template/svg/visa.svg') }}" class="h-full" alt="Visa"></li>
    <li class="!m-0"><img src="{{ asset('template/svg/logo-paynet.svg') }}" class="h-full" alt="Paynet"></li>
</ul>