{{$widget->title_top}}
{{$widget->title}}
{{$widget->title_bottom}}
{!! $widget->content !!}
{{ url('storage/'.$widget->image) }}