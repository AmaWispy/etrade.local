<div class="showing-product-number xl:text-right text-start xl:text-base  !text-2xl font-semibold">
    <p>{{ __('template.results_count', ['from' => $on_page, 'total' => $total]) }}</p>
</div> 