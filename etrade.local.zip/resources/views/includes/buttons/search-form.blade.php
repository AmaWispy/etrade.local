<form method="get" action="/search/products">
    <input type="text" name="sq" value="" placeholder="{{ __('template.search') }}..."/>
    <button type="submit">
        <span><i class="icon-magnifier"></i></span>
    </button>
</form>