@extends('errors::minimal')

@section('title', 'Be right back')
@section('code', 'Be right back')
@section('message', 'Demo is being refreshed.')
