<?php

namespace App\Http\Controllers;

class AuthController extends Controller
{
    public function view(){
        return view('pages.auth');
    }
}